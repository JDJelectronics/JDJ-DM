/*
***************************************************************************  
**  Program  : index.js, part of JDJ-DM
**
**  Copyright (c) 2020 Willem Aandewiel
**
**  TERMS OF USE: MIT License. See bottom of file.                                                            
***************************************************************************      
*/
  const APIGW='http://'+window.location.host+'/api/';

"use strict";

  let needReload  = true;
  
  window.onload=bootsTrap;
  window.onfocus = function() {
    if (needReload) {
      window.location.reload(true);
    }
  };
    
  //============================================================================  
  function bootsTrap() {
    console.log("bootsTrap()");
    document.getElementById('overruleswitch').addEventListener('click',function()
                                                {setState();});
    document.getElementById('downloadLog').addEventListener('click',function()
                                                {requestListLogApi();});
    needReload = false;
    refreshDMdata();
    TimerTime = setInterval(refreshDMdata, 5 * 1000); // repeat every 10s
  
  } // bootsTrap()
  
  //============================================================================  
  function refreshDMdata()
  {
    console.log("refreshDMdata() ..");
    fetch(APIGW+"dmstate")
      .then(response => response.json())
      .then(json => {
        console.log("parsed --> json is ["+ JSON.stringify(json)+"]");
        data = json.dmstate;
        //console.log("data[0].temp is ["+ data[0].temp +"]");
        document.getElementById('temp').innerHTML = data[0].temp;
        //console.log("humidity is ["+ data[0].humid +"]");
        document.getElementById('humid').innerHTML = data[0].humid;
        //console.log("dewpoint is ["+ data[0].dewpoint +"]");
        document.getElementById('dewpoint').innerHTML = data[0].dewpoint;
        document.getElementById('voltage').innerHTML = data[0].voltage;
        document.getElementById('heaterTxt').innerHTML = "Heater Off";
        if (document.getElementById("overruleswitch").checked)
        {
          document.getElementById('overruletime').value = data[0].switchtimer;
        }
        if (data[0].switch == 1)
              document.getElementById("overruleswitch").checked = true;
        else  document.getElementById("overruleswitch").checked = false;

        if (data[0].relaystate == 1)
        {
              document.getElementById('heaterTxt').innerHTML = "Heater On (timer)";
              document.getElementById("timerImg").src = "/timerOn.png";
        }
        else  document.getElementById("timerImg").src = "/timerOff.png";

        if (data[0].acculowstate == 1)
        {
          console.log("accu Low state!!");
          document.getElementById("voltage").style.color = "red";
          document.getElementById("overruleswitch").checked   = false;
          document.getElementById("overruleswitch").disabled  = true;
        }
        else 
        {
          document.getElementById("voltage").style.color = "white";
          document.getElementById("overruleswitch").disabled  = false;
        }
                
        if (data[0].dewpointalarmstate == 1) 
        {
              document.getElementById('heaterTxt').innerHTML = "Heater On (Dewpoint)";
              document.getElementById("timerImg").src = "/heaterOn.png";
              document.getElementById("overruleswitch").checked   = false;
              document.getElementById("overruleswitch").disabled  = true;
        }

        if (data[0].accuenabled == 1)
              document.getElementById('showVoltage').style.display = 'block';
        else  document.getElementById('showVoltage').style.display = 'none';
        
      })
      .catch(function(error) {
        var p = document.createElement('p');
        p.appendChild(
          document.createTextNode('Error: ' + error.message)
        );
      });     
  } // refreshDMdata()
  
  
  //============================================================================  
  function setState() {
    console.log("in setState() ..");
    if (document.getElementById("overruleswitch").checked)
    {
      console.log("State is checked");
      document.getElementById("timerImg").src = "/timerOn.png";
      sendSwitchApi(1);
    }
    else
    {
      console.log("State is Un-checked");
      document.getElementById("timerImg").src = "/timerOff.png";
      sendSwitchApi(0);
    }
  } // setState();

  
  //============================================================================  
  function sendSwitchApi(value) {

    const other_params = {
            headers : { "content-type" : "application/json; charset=UTF-8"},
            method : "POST",
            mode : "cors"
    };
    if (value == 1)
    {
      sendSwitchTimeApi();
      fetch(APIGW+"switch/set/on", other_params)
        .then(function(response) {
       }, function(error) {
         console.log("Error["+error.message+"]"); //=> String
      });
    }
    else
    {
      fetch(APIGW+"switch/set/off", other_params)
        .then(function(response) {
       }, function(error) {
         console.log("Error["+error.message+"]"); //=> String
      });
    }
  } // sendSwitchApi()

  
  //============================================================================  
  function sendSwitchTimeApi() {

    let timeSet = document.getElementById("overruletime").value;
    console.log("overruleTime["+timeSet+"]");

    const other_params = {
            headers : { "content-type" : "application/json; charset=UTF-8"},
            method : "POST",
            mode : "cors"
    };
    fetch(APIGW+"switch/set/timer/"+timeSet, other_params)
      .then(function(response) {
     }, function(error) {
       console.log("Error["+error.message+"]"); //=> String
    });
  } // sendSwitchTimeApi()


  //============================================================================  
  function requestListLogApi() {
    console.log("requestListLogApi()..");
    moment.locale(); 
    var date = moment().format("YYYY-MM-DD-HH:mm");
    var fileName = "DM-"+date+".csv";
    console.log("fileName["+fileName+"]");
    downloadLog(APIGW+"listlog", fileName);
  } // requestListLogApi()

  //============================================================================  
  function downloadLog(url, filename) 
  {
    fetch(url).then(function(t) {
      return t.blob().then((b)=>{
          var a = document.createElement("a");
          a.href = URL.createObjectURL(b);
          a.setAttribute("download", filename);
          a.click();
        }
      );
    });
  } // downloadLog()
  
  //============================================================================  
  function round(value, precision) {
    var multiplier = Math.pow(10, precision || 0);
    return Math.round(value * multiplier) / multiplier;
  }

  
  //============================================================================  
  function printAllVals(obj) {
    for (let k in obj) {
      if (typeof obj[k] === "object") {
        printAllVals(obj[k])
      } else {
        // base case, stop recurring
        console.log(obj[k]);
      }
    }
  } // peintAllVals()
  
/*
***************************************************************************
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to permit
* persons to whom the Software is furnished to do so, subject to the
* following conditions:
*
* The above copyright notice and this permission notice shall be included
* in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
* OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
* THE USE OR OTHER DEALINGS IN THE SOFTWARE.
* 
***************************************************************************
*/
