

#include <Arduino.h>
#include <U8g2lib.h>
#include "DHT.h"              // - DHT Sensor Library: https://github.com/adafruit/DHT-sensor-library
#include <WiFiUdp.h>          // - part of ESP8266 Core https://github.com/esp8266/Arduino
#include <TimeLib.h>
#include <Wire.h>
#include <ESP8266WiFi.h>
#include <DNSServer.h>        // - part of ESP8266 Core https://github.com/esp8266/Arduino
#include <ESP8266mDNS.h>
#include <ESP8266WebServer.h>
#include <WiFiManager.h>
#include <FS.h>               // - part of ESP8266 Core https://github.com/esp8266/Arduino
#include <TelnetStream.h>     // - Version 0.0.1 - https://github.com/jandrassy/TelnetStream
#include "Debug.h"
#include "safeTimers.h"
#include <ModUpdateServer.h>  // - https://github.com/mrWheel/ModUpdateServer
#include "updateServerHTML.h"
#include "ESP_SysLogger.h"    // - https://github.com/mrWheel/ESP_SysLogger

#define TEST_GPIOS            // overrule the real GPIO states of ACCU_VOLTAGE_SELECTOR and ACCU_ENABLED

#define _HOSTNAME             "JDJ-DM"
#define SDA_PIN               4       
#define SCL_PIN               5       
#define RELAY_PIN             16
#define DHT_PIN               13
#define HEATER_SWITCH_PIN     0
#define ACCU_PIN              A0      // Analog channel A0 as used to measure accu voltage
#define ACCU_VOLT_SELECTOR    14      // GPIO14 -> LOW is 12V, HIGH is 24V
#define ACCU_ENABLED          12      // GPIO12 -> LOW = accuEnabled
#define MAX_ACCU_DROP         0.1     // production 0.1 // 12 * 0.1 = 1.2v, 24 * 0.1 = 2.4v
#define READ_ACCU_INTERVAL    10      // minutes
#define READ_SENSOR_INTERVAL  20      // every 20 seconds (and with every api-call) -> 1 minute in production
#define _RELAY_ON             HIGH
#define _RELAY_OFF            LOW

// Uncomment whatever type you're using!
#define DHTTYPE DHT11   // DHT 11
// #define DHTTYPE DHT22   // DHT 22  (AM2302), AM2321
// #define DHTTYPE DHT21   // DHT 21 (AM2301)

//                                  1         2         3         4         5         6         7         8         9        10
//                         12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234
#define _CSV_LOG_HEADER   "      Date;     Time; TempC; Humidity; Dewpoint; AccuVolt; DPAlarm; Override; accuLow; RelayState; Message;"
// example:                2020-01-12; 17:45:01;  23.0;     50.0;     12.0;      8.9;       1;        0;       1;          1;        ; 

#define writeToSysLog(...) ({ sysLog.writeDbg( sysLog.buildD("%04d-%02d-%02d; %02d:%02d:%02d; "     \
                                               , year(), month(), day(), hour(), minute(), second()) \
                                               ,__VA_ARGS__); })

enum u8g2States {  u8g2_InitState, u8g2_AlarmState, u8g2_OnState, u8g2_OffState, u8g2_ManualState
                 , u8g2_ConnState, u8g2_CheckState, u8g2_VoltCheckState, u8g2_VoltReadState
                 , u8g2_VoltDoneState, u8g2_FWState, u8g2_WiFiState, u8g2_SetTimerState
                 , u8g2_RebootState 
                };
                 

DHT       dht(DHT_PIN, DHTTYPE);
ESPSL     sysLog;                   // Create instance of the ESPSL object

// Global Var's
float     actTempC        = 0.0;
float     actHumidity     = 0.0;
float     actDewPoint     = 0.0;
float     DewpointAlarm   = 0.0;
float     accuNominal     = 22.0;   // this depends on accu (12v/24v) whitch depends on two GPIO-pin states
float     actVoltage      = 0.0;
bool      accuLowState    = false;
int32_t   actAnalogVal    = 0;
float     maxDropOffset   = 0.0;
int8_t    DewpointAlarmState = 0;
int8_t    actRelayState   = 0;
bool      prevSwitch      = false;
int8_t    overruleSwitch  = 0;
int16_t   overruleTimer   = 15;
uint32_t  minutesTimer    = 0;
uint32_t  switchTimer     = 0;
uint32_t  rebootTimer     = 0;

uint32_t  upTimeSeconds   = 0;
uint32_t  nextSecond      = 0;
uint32_t  nrOfReboots     = 0;
int8_t    lastHour        = 0;
uint32_t  lastEpoch       = 0;
bool      accuEnabled     = false;
bool      Verbose1        = false;
bool      Verbose2        = false;

#ifdef TEST_GPIOS
    bool GPIO_Accu_Enabled        = false;
    bool GPIO_Accu_Volt_Selector  = false;
#endif
FSInfo SPIFFSinfo;


char objSprtr[10]         = "";
char logLine[50]          = "";

// Oled 0.96                                      reset          clock data
U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE, 5,    4);   // ESP32 Thing, HW I2C with pin remapping


// Create WebServer object on port 80
ESP8266WebServer httpServer(80);  

ESP8266HTTPUpdateServer httpUpdater(true);


DECLARE_TIMER_MIN(accuTimer, READ_ACCU_INTERVAL);
DECLARE_TIMER_SEC(sensorTimer, READ_SENSOR_INTERVAL);
